{ config, lib, pkgs, modulesPath, ... }:

let
  rootDev    = "/dev/disk/by-uuid/a6a0c61f-da67-4550-9e7e-04ec82c09086";
  commonOpts = [ "noatime" "compress=zstd:1" "ssd" "space_cache=v2" "discard=async" ];
in
{
  imports = [ (modulesPath + "/installer/scan/not-detected.nix") ];

  boot.initrd.availableKernelModules = [
    "nvme" "xhci_pci" "ahci" "usb_storage" "usbhid" "sd_mod"
    "btrfs"
  ];

  boot.initrd.luks.devices."cryptroot" = {
    device           = "/dev/disk/by-uuid/52cbcdec-d29e-485b-9f49-2000ebf5fe35";
    allowDiscards    = true;
    bypassWorkqueues = true;
  };

  fileSystems."/" = {
    device  = rootDev;
    fsType  = "btrfs";
    options = commonOpts ++ [ "subvol=@" ];
  };

  fileSystems."/home" = {
    device  = rootDev;
    fsType  = "btrfs";
    options = commonOpts ++ [ "subvol=@home" ];
    neededForBoot = true;
  };

  fileSystems."/nix" = {
    device  = rootDev;
    fsType  = "btrfs";
    options = [ "noatime" "nodatacow" "ssd" "space_cache=v2" "discard=async" "subvol=@nix" ];
  };

  fileSystems."/var/log" = {
    device  = rootDev;
    fsType  = "btrfs";
    options = [ "noatime" "ssd" "space_cache=v2" "discard=async" "subvol=@log" ];
  };

  fileSystems."/.snapshots" = {
    device  = rootDev;
    fsType  = "btrfs";
    options = commonOpts ++ [ "subvol=@snapshots" ];
  };

  fileSystems."/boot" = {
    device  = "/dev/disk/by-uuid/C47D-CA38";
    fsType  = "vfat";
    options = [ "fmask=0077" "dmask=0077" ];
  };

  swapDevices = [{
    device = "/dev/disk/by-uuid/71c693b0-c7cc-4bc3-835f-44694ce9bad0";
    priority = 10;
  }];

  nixpkgs.hostPlatform = lib.mkDefault "x86_64-linux";
  hardware.cpu.amd.updateMicrocode = lib.mkDefault config.hardware.enableRedistributableFirmware;
}
